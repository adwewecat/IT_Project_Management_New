@echo off
title KIEM TRA KET NOI KDS MAN HINH BEP - WIN SERVER
setlocal enabledelayedexpansion

echo ===============================================================================
echo   CONG CU TEST KET NOI KDS TRUC TIEP TREN WINDOWS SERVER
echo ===============================================================================
echo.
set /p TEST_IP="Nhap dia chi IP KDS can ket noi (vi du 10.8.160.31): "
if "%TEST_IP%"=="" (
    echo [LOI] Ban chua nhap dia chi IP!
    pause
    exit /b 1
)

call "C:\scrcpy\kds_connect_server.bat" "scrcpy://%TEST_IP%"

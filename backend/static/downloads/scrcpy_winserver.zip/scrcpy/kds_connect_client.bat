@echo off
title KET NOI KDS MAN HINH BEP - CLIENT PC
setlocal enabledelayedexpansion

set RAW_URL=%~1
set IP=%RAW_URL:scrcpy://=%
set IP=%IP:/=%
set IP=%IP:"=%
set IP=%IP: =%

if "%IP%"=="" (
    set /p IP="Nhap dia chi IP cua KDS (vi du 10.8.160.31): "
)

echo ===============================================================================
echo   KET NOI SCRCPY KDS MAN HINH BEP - CLIENT PC (D3D11 / HARDWARE ACCELERATED)
echo   Dia chi IP KDS: %IP%
echo   Toi uu: 2.5 Mbps, 30fps, Tat audio, Giu sang man hinh, Buffer 50ms
echo ===============================================================================
echo.

cd /d "C:\scrcpy"

echo [1/3] Reset ket noi ADB cu toi %IP%:5555...
adb.exe disconnect %IP%:5555 >nul 2>&1

echo [2/3] Dang ket noi ADB toi %IP%:5555...
adb.exe connect %IP%:5555
echo.

echo [3/3] Dang khoi chay Scrcpy (Hardware Accelerated)...
scrcpy.exe -s %IP%:5555 --window-title "KDS - %IP%" --no-audio --video-bit-rate=2.5M --max-fps=30 --max-size=1600 --stay-awake --video-buffer=50
if not errorlevel 1 goto :KetThucOk

echo.
echo ===============================================================================
echo   CANH BAO: Che do Toi uu gap su co, dang thu lai voi Fallback...
echo ===============================================================================
scrcpy.exe -s %IP%:5555 --window-title "KDS - %IP%" --no-audio
if not errorlevel 1 goto :KetThucOk

echo.
echo ===============================================================================
echo   LOI KHOI CHAY SCRCPY!
echo   Kiem tra xem IP %IP% co ping duoc khong va thiet bi KDS da bat Debug ADB chua.
echo ===============================================================================
echo Cua so se tu dong dong sau 15 giay, hoac bam phim bat ky de thoat ngay...
timeout /t 15 >nul 2>nul || ping 127.0.0.1 -n 16 >nul
exit /b 1

:KetThucOk
echo.
echo Da dong ket noi KDS %IP% thanh cong.
exit /b 0

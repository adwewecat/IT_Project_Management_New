@echo off
title KET NOI KDS MAN HINH BEP - WINDOWS SERVER / RDP
setlocal enabledelayedexpansion

set RAW_URL=%~1
set IP=%RAW_URL:scrcpy://=%
set IP=%IP:/=%
set IP=%IP:"=%
set IP=%IP: =%

if "%IP%"=="" (
    set /p IP="Nhap dia chi IP cua KDS (vi du 10.8.160.31): "
)

echo ===============================================================================
echo   KET NOI SCRCPY KDS MAN HINH BEP - WINDOWS SERVER / RDP
echo   Dia chi IP KDS: %IP%
echo ===============================================================================
echo.

cd /d "C:\scrcpy"

:: Thiet lap moi truong bat buoc cho Windows Server va Remote Desktop (RDP)
set SDL_RENDER_DRIVER=software
set SDL_VIDEODRIVER=windows

echo [1/3] Reset ket noi ADB cu toi %IP%:5555...
adb.exe disconnect %IP%:5555 >nul 2>&1

echo [2/3] Dang ket noi ADB toi %IP%:5555...
adb.exe connect %IP%:5555
echo.

echo [3/3] Dang khoi chay Scrcpy (Che do Software Render)...
scrcpy.exe -s %IP%:5555 --window-title "KDS-%IP%" --render-driver=software --no-audio --video-codec=h264
if not errorlevel 1 goto :KetThucOk

echo.
echo ===============================================================================
echo   CANH BAO: Che do Software Render gap su co, dang thu lai voi Fallback...
echo ===============================================================================
scrcpy.exe -s %IP%:5555 --window-title "KDS-%IP%" --no-audio
if not errorlevel 1 goto :KetThucOk

echo.
echo ===============================================================================
echo   LOI KHOI CHAY SCRCPY TREN WINDOWS SERVER!
echo   Huong dan khac phuc su co:
echo   1. Kiem tra xem may Server da cai goi Visual C++ Redistributable (2015-2022) chua.
echo   2. Tren Windows Server 2012: Can bat tinh nang Desktop Experience trong Server Manager.
echo   3. Kiem tra IP %IP% co ping duoc khong va thiet bi KDS da bat che do Debug ADB chua.
echo ===============================================================================
echo Cua so se tu dong dong sau 20 giay, hoac bam phim bat ky de thoat ngay...
timeout /t 20 >nul 2>nul || ping 127.0.0.1 -n 21 >nul
exit /b 1

:KetThucOk
echo.
echo Da dong ket noi KDS %IP% thanh cong.
exit /b 0

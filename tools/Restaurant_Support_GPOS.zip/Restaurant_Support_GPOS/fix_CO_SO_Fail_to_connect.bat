@echo off
echo ===============================
echo   RESTART MONGODB + JAVA TASK
echo ===============================

REM --- 1. Ket thuc tien trinh Java ---
echo [1/7] Stop tien trinh Java(TM) Platform SE binary...
taskkill /F /IM java.exe  >nul 2>&1
taskkill /F /IM javaw.exe >nul 2>&1

REM --- 2. Xac dinh ten service MongoDB ---
set "MDB_SVC="
for %%S in ("MongoDB Server" "MongoDB" "mongodb" "MongoDBServer") do (
  sc query "%%~S" >nul 2>&1 && set "MDB_SVC=%%~S"
)
if "%MDB_SVC%"=="" (
  echo ❌ Khong tim thay service MongoDB. Hay mo Services de kiem tra lai ten chinh xac
  timeout /t 4 /nobreak >nul
  exit /b 1
)
echo Da tim thay service: "%MDB_SVC%"

REM --- 3. Stop MongoDB ---
echo [2/7] Stop service "%MDB_SVC%"...
net stop "%MDB_SVC%"

REM --- 4. Khoi dong lai MongoDB ---
echo [3/7] Khoi dong lai service "%MDB_SVC%"...
net start "%MDB_SVC%"

REM --- 5. Chay lai ung dung Gpos CO/SO Java (an console) ---
echo [4/7] Chay lai ung dung Gpos CO/SO fxlauncher.jar...
if exist "D:\GPOS-Setup\app" (
    cd /d "D:\GPOS-Setup\app"
    start "" javaw -jar fxlauncher.jar
) else (
    echo ⚠️  Gpos KHONG TIM THAY O DIA D
)

REM --- 6. Chay lai ung dung Gpos KDS (an console) ---
echo [5/7] Chay lai ung dung Gpos KDS fxlauncher_kds.jar...
if exist "D:\KDS-GPOS-Setup\app" (
    cd /d "D:\KDS-GPOS-Setup\app"
    start "" javaw -jar fxlauncher_kds.jar
) else (
    echo ⚠️  NHA HANG KHONG DUNG KDS
)


REM --- 7. Chay lai ung dung Gpos PrintStampService IN TEM (an console) ---
echo [6/7] Chay lai ung dung Gpos PrintStampService IN TEM fxlauncher.jar...
if exist "D:\PrintStampService\app" (
    cd /d "D:\PrintStampService\app"
    start "" javaw -jar fxlauncher.jar
) else (
    echo ⚠️  NHA HANG KHONG DUNG PrintStampService IN TEM
)

REM --- 8. Hoan tat ---
echo [7/7] ✅ Hoan tat qua trinh!
echo Cua so nay se tu dong dong sau 4 giay...
timeout /t 4 /nobreak >nul
exit
